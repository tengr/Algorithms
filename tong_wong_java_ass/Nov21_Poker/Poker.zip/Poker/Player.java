public class Player implements Comparable<Player>{
	public int id;
	private Hand hand;
	
	public Player(int id, Hand hand){
		this.id = id;
		this.hand = hand;
	}

	@Override
	public int compareTo(Player anotherPlayer) {
		return (this.hand).compareTo(anotherPlayer.hand);
	}
	@Override
    public  String toString() {
        return this.hand.toString();
    }
}
