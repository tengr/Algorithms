package com.atlassian.codetest.grad;

import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

public class ExtendedSetImpl<T> extends AbstractSet<T> implements ExtendedSet<T> {

    public ExtendedSetImpl(int maxCapacity) {
        super();
    }

    public ExtendedSetImpl(int maxCapacity, Collection<? extends T> collection) {
        super();
    }

    public boolean add(T e) {
        throw new UnsupportedOperationException();
    }

    /**
     * Implementing an iterator here will allow you (and our tests) to use several methods inherited from Set, including
     * contains(T) and addAll(Collection<T>)
     */
    public Iterator<T> iterator() {
        return new Iterator<T>() {

            //In Java, Iterator instance data goes here

            public boolean hasNext() {
                return false;
            }

            public T next() {
                return null;
            }
        };
    }

    public int size() {
        return 0;
    }

    public ExtendedSet<T> union(Set<T> secondSetExtension) {
        return null;
    }

    public ExtendedSet<T> intersect(Set<T> secondSetExtension) {
        return null;
    }

    public ExtendedSet<T> symmetricDifference(Set<T> secondSetExtension) {
        return null;
    }
}
