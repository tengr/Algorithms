# Goals for the test
Implement ExtendedSet such that all the tests pass.
Ensure you are talking through your reasoning for all decisions, and ask any questions to the interviewer!

# Restriction
You can't add any additional imports. That is, don't just wrap a Java set!