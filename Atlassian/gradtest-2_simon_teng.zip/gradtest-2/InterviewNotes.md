For extra information on how to conduct this interview, see https://extranet.atlassian.com/x/RgLanw

Full text has not been copied here to ensure it isn't accidentally viewable by candidates